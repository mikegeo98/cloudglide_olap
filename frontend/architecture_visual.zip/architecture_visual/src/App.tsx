import InteractiveCluster from "./InteractiveCluster";

export default function App() {
  return <InteractiveCluster />;
}
