# Architecture Visual – Interactive Cluster

This project renders an interactive **compute cluster visualization** using **React + SVG**.

You can configure:
- number of nodes
- instance types (vCPU, DRAM, network bandwidth)
- see inter-node network links, storage (S3), and per-node resources

---

## Requirements

- **Node.js v18+**
  https://nodejs.org/

---

## How to run

```bash
npm install
npm run dev
